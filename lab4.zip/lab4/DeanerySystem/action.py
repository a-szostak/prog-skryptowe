from enum import Enum

class Action(Enum):
    DAY_EARLIER = 1
    DAY_LATER = 2
    TIME_EARLIER = 3
    TIME_LATER = 4
